package com.up.calculadora

import androidx.appcompat.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.view.Menu
import android.view.MenuItem
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.Expression
import net.objecthunter.exp4j.ExpressionBuilder
import com.google.firebase.crashlytics.FirebaseCrashlytics


class MainActivity : AppCompatActivity() {
    private lateinit var expressaoTextView: TextView
    private lateinit var resultadoTextView: TextView
    private var expressao = ""
    private var resultado = ""
    private lateinit var sharedPreferences: SharedPreferences
    private val historico = mutableListOf<String>()

    companion object {
        private const val PREF_NAME = "CalculadoraPrefs"
        private const val HISTORICO_KEY = "historico"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        expressaoTextView = findViewById(R.id.expressao)
        resultadoTextView = findViewById(R.id.txt_resultado)
        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        carregarHistorico()

        val numeros = listOf(
            R.id.numero_zero, R.id.numero_um, R.id.numero_dois, R.id.numero_tres,
            R.id.numero_quatro, R.id.numero_cinco, R.id.numero_seis, R.id.numero_sete,
            R.id.numero_oito, R.id.numero_nove
        )

        val operadores = listOf(
            R.id.soma, R.id.subtracao, R.id.multiplicacao, R.id.divisao, R.id.parenteses1, R.id.parenteses2
        )

        for (numeroId in numeros) {
            findViewById<View>(numeroId).setOnClickListener { onNumeroClicado(numeroId) }
        }

        for (operadorId in operadores) {
            findViewById<View>(operadorId).setOnClickListener { onOperadorClicado(operadorId) }
        }

        findViewById<View>(R.id.ponto).setOnClickListener { onPontoClicado() }
        findViewById<View>(R.id.limpar).setOnClickListener { onLimparClicado() }
        findViewById<View>(R.id.igual).setOnClickListener { onIgualClicado() }
        findViewById<View>(R.id.backspace).setOnClickListener { onBackspaceClicado() }

        val btnHistorico = findViewById<ImageButton>(R.id.btnHistorico)
        btnHistorico.setOnClickListener {
            exibirHistorico()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_historico -> exibirHistorico()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun exibirHistorico() {
        val historicoArray = historico.toTypedArray()

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Histórico")
            .setItems(historicoArray) { _, _ -> }
            .setPositiveButton("Fechar") { dialog, _ -> dialog.dismiss() }

        val dialog = builder.create()
        dialog.show()
    }

    private fun carregarHistorico() {
        historico.clear()
        historico.addAll(sharedPreferences.getStringSet(HISTORICO_KEY, setOf()) ?: setOf())
    }

    private fun salvarHistorico() {
        val editor = sharedPreferences.edit()
        editor.putStringSet(HISTORICO_KEY, historico.toSet())
        editor.apply()
    }

    private fun onNumeroClicado(id: Int) {
        val numero = findViewById<TextView>(id).text.toString()
        expressao += numero
        atualizarExpressaoEResultado()
    }

    private fun onOperadorClicado(id: Int) {
        val operador = findViewById<TextView>(id).text.toString()
        expressao += " $operador "
        atualizarExpressaoEResultado()
    }

    private fun onPontoClicado() {
        expressao += "."
        atualizarExpressaoEResultado()
    }

    private fun onLimparClicado() {
        expressao = ""
        resultado = ""
        atualizarExpressaoEResultado()
    }

    private fun onIgualClicado() {
        try {
            val expression: Expression = ExpressionBuilder(expressao).build()
            resultado = expression.evaluate().toString()

            historico.add("$expressao = $resultado")

            salvarHistorico()
        } catch (e: Exception) {
            resultado = "Erro"

            FirebaseCrashlytics.getInstance().recordException(e)
        }
        atualizarExpressaoEResultado()
    }

    private fun onBackspaceClicado() {
        if (expressao.isNotEmpty()) {
            expressao = expressao.substring(0, expressao.length - 1)
            atualizarExpressaoEResultado()
        }
    }

    private fun atualizarExpressaoEResultado() {
        expressaoTextView.text = expressao
        resultadoTextView.text = resultado
    }
}
